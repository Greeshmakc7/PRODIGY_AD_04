package com.techsoldev.tictactoegame;

public class MyServices {

    public static boolean VIBRATION_CHECK=false;
    public static boolean SOUND_CHECK=true;



}
